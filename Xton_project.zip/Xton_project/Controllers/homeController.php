<?php 
require_once('Models/alldb.php');
$result = getArrivals();
?>