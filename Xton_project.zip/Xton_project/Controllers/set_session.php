<?php
session_start();
$_SESSION['restaurant'] = "Restaurant";
$_SESSION['restaurant2'] = "Restaurant2";
?>