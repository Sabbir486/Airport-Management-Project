<?php
require_once('../Models/Admin_Db_Functions.php');
$List1=Admin_Yearly_Revenue_Show1();
$List2=Admin_Yearly_Revenue_Show2();
?>
