<?php
require_once('../Models/Admin_Db_Functions.php');
$List=Admin_Review_Comment();
?>