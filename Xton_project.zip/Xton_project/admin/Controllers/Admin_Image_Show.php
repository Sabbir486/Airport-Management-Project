<?php
require_once('../Models/Admin_Db_Functions.php');
$Image=Admin_Image_Show();
?>