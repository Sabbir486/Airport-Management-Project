<?php
require_once('../Models/Admin_Db_Functions.php');
$List=Admin_Avarage_Earnings_Show();
?>
