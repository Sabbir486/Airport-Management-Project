<?php
require_once('../Models/Admin_Db_Functions.php');
$name=Admin_Name_Show();
?>